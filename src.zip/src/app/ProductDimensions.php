<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductDimensions extends Model
{
    protected $fillable = ['name'];
}
