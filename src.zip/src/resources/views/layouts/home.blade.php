@extends('layouts.master')

@section('content')

<div class="container-fluid">
    <div class="row">
        <div class="col-3"></div>
        <div class="col-6">
            <img src="{{ asset('/images/LOGO_HUAHAI_LED.jpg') }}" alt="homepage" class="dark-logo" />
        </div>
        <div class="col-3"></div>
    </div>
</div>

@endsection
