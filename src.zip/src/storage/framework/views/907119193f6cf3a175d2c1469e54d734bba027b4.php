<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="row">
        <div class="col-3"></div>
        <div class="col-6">
            <img src="<?php echo e(asset('/images/LOGO_HUAHAI_LED.jpg')); ?>" alt="homepage" class="dark-logo" />
        </div>
        <div class="col-3"></div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/layouts/home.blade.php ENDPATH**/ ?>