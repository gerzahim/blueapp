<?php $__env->startSection('content'); ?>

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row">
            <div class="col-12 align-self-center">
                <h4 class="page-title text-truncate text-dark font-weight-medium mb-1">Inventory</h4>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->



    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">

                        <div class="row">
                            <!-- Column -->
                            <div class="col-md-12">
                                <h4 class="font-light">Stock List</h4>
                            </div>
                        </div>

                        <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                        <?php endif; ?>
                        <table class="table table-bordered">
                            <thead class="bg-primary text-white">
                                <tr>
                                    <th>No</th>
                                    <th>Product</th>
                                    <th>PO</th>
                                    <th>Purchased</th>
                                    <th>Sold</th>
                                    <th>QOH</th>
                                    <th>On Hold</th>
                                    <th>Available</th>
                                    <th>RMA</th>
                                    <th>Refurbished</th>
                                    <th>Lended</th>
                                </tr>
                            </thead>
                            <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tbody>
                                    <tr class="text-center">
                                        <td>
                                            <?php echo e($key + 1); ?>

                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('stock.show',$stock->id)); ?>">
                                                <?php echo e($products[$stock->product_id]); ?>

                                            </a>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('stock.show',$stock->id)); ?>">
                                                <?php echo e($purchases[$stock->purchases_id]); ?>

                                            </a>
                                        </td>
                                        <td><?php echo e($stock->purchased); ?></td>
                                        <td><?php echo e($stock->sold); ?></td>
                                        <td><?php echo e($stock->qoh); ?></td>
                                        <td><?php echo e($stock->on_hold); ?></td>
                                        <td><?php echo e($stock->available); ?></td>
                                        <td><?php echo e($stock->rma); ?></td>
                                        <td><?php echo e($stock->refurbished); ?></td>
                                        <td><?php echo e($stock->lended); ?></td>
                                    </tr>
                                </tbody>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <?php echo $stocks->links(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Container fluid  -->
    <!-- ============================================================== -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/stock/index.blade.php ENDPATH**/ ?>